require 'test_helper'

class TaskTest < ActiveSupport::TestCase
end
