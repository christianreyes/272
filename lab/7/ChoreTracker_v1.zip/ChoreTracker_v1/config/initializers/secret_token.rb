# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ChoreTracker::Application.config.secret_token = '30a0878302acd109d7bbdc0ac768ac62b5ee157d760c6c37d2538c55b6196b74ad3ab9bf02afa79f6b050f32f1a913982a4dfb6757c4ae8836dc49c8f79c80b3'
