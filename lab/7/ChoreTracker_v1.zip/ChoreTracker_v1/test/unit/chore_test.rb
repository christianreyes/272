require 'test_helper'

class ChoreTest < ActiveSupport::TestCase

end
