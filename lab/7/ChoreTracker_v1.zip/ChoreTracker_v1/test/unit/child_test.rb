require 'test_helper'

class ChildTest < ActiveSupport::TestCase

end
