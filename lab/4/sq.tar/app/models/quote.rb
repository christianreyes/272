class Quote < ActiveRecord::Base
end
