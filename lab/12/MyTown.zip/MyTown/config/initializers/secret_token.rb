# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MyTown::Application.config.secret_token = '613465d5582430ff409c1a833bf0a47a30b7538f7f17f0377a1b33b6cfe667e9ec277e3e285f431badfc57685c575a14d85d1a9bbed31dbe227723674a99cfe5'
